function Table() {

  let fr= +document.getElementById("fnr").value;
  let lr= +document.getElementById("lnr").value;
  let fc= +document.getElementById("fnc").value;
  let lc= +document.getElementById("lnc").value;

  if(isNaN(fr)|| fr == ""){
    document.getElementById("notification").innerHTML="Warning: Minimum Row value missing or error!";
    return;
  }
  if(isNaN(lr)|| lr == ""){
    document.getElementById("notification").innerHTML="Warning: Maximum Row value missing or error!";
    return;
  }
  if(isNaN(fc)|| fc == ""){
    document.getElementById("notification").innerHTML="Warning: Minimum column value missing or error!";
    return;
  }
  if(isNaN(lc)|| lc == ""){
    document.getElementById("notification").innerHTML="Warning: Maximum column value missing or error!";
    return;
  }
  
  // fr = +fr;
  // lr = +lr;
  // fc = +fc;
  // lc = +lc;

  if (fr > lr){
    document.getElementById("notification").innerHTML="Warning: Mini value greater than Max value in row!";
    return;
  }
  if (fc > lc){
    document.getElementById("notification").innerHTML="Warning: Mini value greater than Max value in column!";
    return;
  }

  
  
  
  var tbl = document.createElement("table");
  tbl.setAttribute("id", "myTable");
  const tblBody = document.createElement("tbody");
  const row2 = document.createElement("tr");
  tblBody.appendChild(row2);
  tbl.appendChild(tblBody);
  document.body.appendChild(tbl);
  tbl.parentNode.insertBefore(tbl,document.getElementById("alert"));

  let table = document.getElementById("myTable");
  let row = table.insertRow(0);

  for (let i = fr; i <= lr; i++) {
    row.insertCell(i - fr).innerHTML = i * 1;
    table.rows[0].cells[i - fr].setAttribute("id", "thead");
  }

  row.insertCell(0).innerHTML = " ";
  table.rows[0].cells[0].setAttribute("id", "thead");
  for (let i = fc; i <= lc; i++) {
    row = table.insertRow(i-fc+1);
    row.insertCell(0).innerHTML = i * 1;
    table.rows[i-fc+1].cells[0].setAttribute("id", "thead");
    for (let j = fr; j <= lr; j++) {
      row.insertCell(j - fr+1).innerHTML = i*j;
      if((i-fc+1)%2 == 0)
        table.rows[i-fc+1].cells[j - fr+1].setAttribute("id", "odd");
    }
  }
}

function removeAlert(){
  document.getElementById("notification").innerHTML="";
}
function removeTable()
{
  var tbl = document.getElementById("myTable");
  if (tbl)
    tbl.parentNode.removeChild(tbl);
}

